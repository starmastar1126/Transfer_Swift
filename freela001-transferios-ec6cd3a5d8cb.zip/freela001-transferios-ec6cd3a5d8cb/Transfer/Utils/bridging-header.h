//
//  bridging-header.h
//  Transfer
//
//  Created by Elian Medeiros on 06/03/18.
//  Copyright © 2018 Transfer+. All rights reserved.
//

#ifndef bridging_header_h
#define bridging_header_h

#endif /* bridging_header_h */

#import <SVGKit/SVGKit.h>
#import <SVGKit/SVGKImage.h>
